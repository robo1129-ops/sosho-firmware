SO-SHO: right trackball Central + left trackpad Peripheral only.
Right firmware: Studio RPC stack and BLE connection lifetime fixes (2026-11-14).
Left firmware is unchanged from the 2026-11-13 package.
User keymap/settings are preserved; do not flash settings-reset.
