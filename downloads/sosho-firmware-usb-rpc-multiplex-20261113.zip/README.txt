﻿SO-SHO USB/BLE RPC firmware
Target: right-side Central / XIAO nRF52840
Flash: extract this ZIP, enter bootloader mode on the right side, and copy the UF2 to the XIAO-BOOT drive.
Keymap editing uses the SO-SHO web application over right-side USB or BLE.
This build separates USB and BLE RPC response routing and stabilizes the first USB read.
SHA-256: B01EC11D530DFBEB600951B6CDA40EF97C7C042EBE6A9393B2BC522812AD76E0
