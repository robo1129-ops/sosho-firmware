﻿SO-SHO USB/BLE RPC firmware
Right: sosho-right-central-usb-rpc-multiplex.uf2
Left: sosho-left-trackpad-usb-rpc-multiplex.uf2
Flash each module in bootloader mode by copying its UF2 to XIAO-BOOT.
